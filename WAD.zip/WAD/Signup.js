import React from "react";
import "./Form.css";

function Signup() {
  const handleSignupSubmit = (event) => {
    event.preventDefault();
  };

  return (
    <div className="form-container">
      <h2>Sign Up</h2>
      <form onSubmit={handleSignupSubmit}>
        <label>
          First Name:
          <input type="text" name="firstName" required />
        </label>
        <label>
          Last Name:
          <input type="text" name="lastName" required />
        </label>
        <label>
          Username:
          <input type="text" name="username" required />
        </label>
        <label>
          Password:
          <input type="password" name="password" required />
        </label>
        <label>
          Email:
          <input type="email" name="email" required />
        </label>
        <label>
          Phone Number:
          <input type="tel" name="phoneNumber" required />
        </label>
        <label>
          Address:
          <input type="text" name="address" required />
        </label>
        <label>
          City:
          <input type="text" name="city" required />
        </label>
        <label>
          State:
          <input type="text" name="state" required />
        </label>
        <label>
          Zip Code:
          <input type="text" name="zipCode" required />
        </label>
        <label>
          Country:
          <input type="text" name="country" required />
        </label>
        <label>
          Date of Birth:
          <input type="date" name="dob" required />
        </label>
        <label>
          Gender:
          <select name="gender" required>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </label>
        <button type="submit">Sign Up</button>
      </form>
    </div>
  );
}

export default Signup;
