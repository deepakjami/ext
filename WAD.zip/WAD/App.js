import React from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import "./App.css";
import Login from "./Login";
import Signup from "./Signup";

//npm install react-router-dom

function App() {
  const catalogItems = [
    {
      id: 1,
      name: "STMPD LIQUID TSHIRT",
      price: "$10",
      imageUrl:
        "https://shop.martingarrix.com/cdn/shop/files/DSC19813.png?v=1719404566&width=713",
    },
    {
      id: 2,
      name: "GARRIX RADAR",
      price: "$15",
      imageUrl:
        "https://shop.martingarrix.com/cdn/shop/files/DSC19811.png?v=1719390830&width=600",
    },
    {
      id: 3,
      name: "REPLAY FOR MARTIN GARRIX",
      price: "$20",
      imageUrl:
        "https://shop.martingarrix.com/cdn/shop/files/MMG353BACK.png?v=1719311164&width=600",
    },
    {
      id: 4,
      name: "Black Silver T-Shirt",
      price: "$25",
      imageUrl:
        "https://shop.martingarrix.com/cdn/shop/files/DSC19809.png?v=1719409267&width=600",
    },
  ];

  return (
    <Router>
      <div className="App">
        <nav className="navbar">
          <div className="navbar-logo">
            <h1>WAD EXTERNAL</h1>
          </div>
          <ul className="navbar-links">
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/sales">Sales</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
            <li>
              <Link to="/cart">Cart</Link>
            </li>
            <li>
              <Link to="/login">Login</Link>
            </li>
            <li>
              <Link to="/signup">Sign Up</Link>
            </li>
          </ul>
        </nav>

        <Routes>
          <Route
            path="/"
            element={
              <div className="catalog">
                <h2>Catalog</h2>
                <div className="catalog-items">
                  {catalogItems.map((item) => (
                    <div key={item.id} className="catalog-item">
                      <div className="item-image">
                        <img src={item.imageUrl} alt={item.name} />
                      </div>
                      <p>{item.name}</p>
                      <p>{item.price}</p>
                      <button>Add to Cart</button>
                    </div>
                  ))}
                </div>
              </div>
            }
          />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
        </Routes>

        <footer className="footer">
          <p>&copy; 22071A0525 - SAI DEEPAK JAMI.</p>
        </footer>
      </div>
    </Router>
  );
}

export default App;
